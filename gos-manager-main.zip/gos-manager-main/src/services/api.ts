
import axios from 'axios';
import { Machine, ServiceOrder, Labor, Part } from '../types/models';

// URL base da API - altere para a URL do seu backend Spring Boot
const API_URL = 'http://localhost:8080/api';

// Configuração do Axios com interceptadores para token JWT
const api = axios.create({
  baseURL: API_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Interceptador para adicionar o token JWT a todas as requisições
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('token');
    if (token) {
      config.headers['Authorization'] = `Bearer ${token}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// Serviços de Autenticação
export const authService = {
  login: async (username: string, password: string) => {
    const response = await api.post('/auth/login', { username, password });
    if (response.data.token) {
      localStorage.setItem('token', response.data.token);
    }
    return response.data;
  },
  logout: () => {
    localStorage.removeItem('token');
  },
  isAuthenticated: () => {
    return !!localStorage.getItem('token');
  }
};

// Serviço de Máquinas
export const machineService = {
  getAll: async (): Promise<Machine[]> => {
    const response = await api.get('/machines');
    return response.data;
  },
  getById: async (id: number): Promise<Machine> => {
    const response = await api.get(`/machines/${id}`);
    return response.data;
  },
  create: async (machine: Machine): Promise<Machine> => {
    const response = await api.post('/machines', machine);
    return response.data;
  },
  update: async (id: number, machine: Machine): Promise<Machine> => {
    const response = await api.put(`/machines/${id}`, machine);
    return response.data;
  },
  delete: async (id: number): Promise<void> => {
    await api.delete(`/machines/${id}`);
  }
};

// Serviço de Ordens de Serviço
export const serviceOrderService = {
  getAll: async (): Promise<ServiceOrder[]> => {
    const response = await api.get('/service-orders');
    return response.data;
  },
  getById: async (id: number): Promise<ServiceOrder> => {
    const response = await api.get(`/service-orders/${id}`);
    return response.data;
  },
  create: async (serviceOrder: ServiceOrder): Promise<ServiceOrder> => {
    const response = await api.post('/service-orders', serviceOrder);
    return response.data;
  },
  update: async (id: number, serviceOrder: ServiceOrder): Promise<ServiceOrder> => {
    const response = await api.put(`/service-orders/${id}`, serviceOrder);
    return response.data;
  },
  delete: async (id: number): Promise<void> => {
    await api.delete(`/service-orders/${id}`);
  }
};

// Serviço de Mão de Obra
export const laborService = {
  getAll: async (): Promise<Labor[]> => {
    const response = await api.get('/labor');
    return response.data;
  },
  getById: async (id: number): Promise<Labor> => {
    const response = await api.get(`/labor/${id}`);
    return response.data;
  },
  create: async (labor: Labor): Promise<Labor> => {
    const response = await api.post('/labor', labor);
    return response.data;
  },
  update: async (id: number, labor: Labor): Promise<Labor> => {
    const response = await api.put(`/labor/${id}`, labor);
    return response.data;
  },
  delete: async (id: number): Promise<void> => {
    await api.delete(`/labor/${id}`);
  }
};

// Serviço de Peças
export const partService = {
  getAll: async (): Promise<Part[]> => {
    const response = await api.get('/parts');
    return response.data;
  },
  getById: async (id: number): Promise<Part> => {
    const response = await api.get(`/parts/${id}`);
    return response.data;
  },
  create: async (part: Part): Promise<Part> => {
    const response = await api.post('/parts', part);
    return response.data;
  },
  update: async (id: number, part: Part): Promise<Part> => {
    const response = await api.put(`/parts/${id}`, part);
    return response.data;
  },
  delete: async (id: number): Promise<void> => {
    await api.delete(`/parts/${id}`);
  }
};

// Serviço de Relatórios
export const reportService = {
  getDashboardData: async () => {
    const response = await api.get('/reports/dashboard');
    return response.data;
  },
  getMachineMaintenanceHistory: async (machineId: number) => {
    const response = await api.get(`/reports/machine/${machineId}/history`);
    return response.data;
  },
  getCostReport: async (startDate: string, endDate: string) => {
    const response = await api.get('/reports/costs', {
      params: { startDate, endDate }
    });
    return response.data;
  },
  exportPdf: async (reportType: string, params: any) => {
    const response = await api.get(`/reports/export/${reportType}`, {
      params,
      responseType: 'blob'
    });
    return response.data;
  }
};

export default api;
